window.onload = function() {
	document.getElementById("bootscreen").style.display = "none"
}

function godash() {
	document.getElementById('dashboardbutton').style.display='block';
}
function destroygodash() {
	document.getElementById('dashboardbutton').style.display='none';
}
function destroygodash() {
	document.getElementById('dashboardbutton').style.display='none';
}
function whiteline() {
	document.getElementById('handle-line').style.background='#fff';
}
function destroywhite() {
	document.getElementById('handle-line').style.background='rgba(255, 255, 255, 0.5)';
}